
"use strict";

let testmsg = require('./testmsg.js');
let radiusArea = require('./radiusArea.js');
let custom_msg = require('./custom_msg.js');

module.exports = {
  testmsg: testmsg,
  radiusArea: radiusArea,
  custom_msg: custom_msg,
};
