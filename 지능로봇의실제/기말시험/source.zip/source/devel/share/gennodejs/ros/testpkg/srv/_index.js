
"use strict";

let calc_area = require('./calc_area.js')
let testsrv = require('./testsrv.js')

module.exports = {
  calc_area: calc_area,
  testsrv: testsrv,
};
