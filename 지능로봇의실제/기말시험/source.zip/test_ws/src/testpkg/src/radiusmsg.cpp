#include "ros/ros.h"
#include "testpkg/radiusArea.h"
#include <cstdlib>
#include <time.h>
#include <iostream>
#include <vector>

std::vector<int> storedVector;
int main(int argc, char **argv)
{
	ros::init(argc, argv, "ramdom_radius");
	ros::NodeHandle n;
	ros::Publisher chatter_pub = n.advertise<testpkg::radiusArea>("custommsg", 1000);
	ros::Rate loop_rate(1);//1hz (1초)
	int count = 0; 
//	long int inbuff[10];
	float outbuff[10];
	int i;

	while (ros::ok())
	{
		testpkg::radiusArea pub_data;

		pub_data.header.frame_id = " ";
		pub_data.header.seq = count;
		pub_data.header.stamp = ros::Time::now();
		//for(i=0; i<10; i++) storedVector.push_back(i) = i;  // 랜덤으로 반지름 생

		//pub_data.inarray = storedVector;
		pub_data.inarray = rand();

		chatter_pub.publish(pub_data);  // 반지름 메시지 발
		std::cout << "send random radius" << std::endl;

	//	ros::spin();  //메시지 수신대
		chatter_pub.publish(pub_data);
		outbuff = pub_data.outarray;

		std::cout << "Area Received" << std::endl;
		ros::spinOnce();  // 콜백 함수 호출
		loop_rate.sleep();  // 일시 정지
		++count;  // 카운트 증가
	

	}
	return 0;
}
