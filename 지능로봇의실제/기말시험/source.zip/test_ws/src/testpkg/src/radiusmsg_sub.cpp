#include "ros/ros.h"
#include "testpkg/radiusArea.h"
#include <iostream>

void msgCallback(const testpkg::radiusArea::ConstPtr& msg)
{

	float buff[10];
	long int ibuff[10];
	std::cout << "callback!\n";
	std::cout << "msg->header.frame_id " << msg->header.frame_id << "\n";
	std::cout << "msg->header.seq " << msg->header.seq << "\n";
	std::cout << "msg->header.stamp " << msg->header.stamp << "\n";

	for (int i = 0; i < 10;i++)
	{
		//buff[i] = (float) msg->inarray.at(i) * msg->inarray.at(i) * 3.141592653589793238;
		ibuff[i] = msg->inarray.at(i);
	}

	std::cout << std::endl;
	msg.outarray = buff;
	chatter_pub.publish(msg.outarray);

}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "calc_server");
	ros::NodeHandle n;
	ros::Subscriber sub = n.subscribe("custommsg", 1000, msgCallback);
	ros::spin();
	return 0;
}
